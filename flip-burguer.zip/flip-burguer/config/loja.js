// ============================================================
//  CONFIGURAÇÃO DA LOJA — gerada pelo Admin em 29/09/2026 às 18:25
//  Para mudar, edite a loja no admin e exporte de novo.
// ============================================================
window.LOJA = {
  "nome": "Flip Burguer",
  "slug": "flip-burguer",
  "logo": "assets/logo.webp",
  "favicon": "assets/icone.png",
  "whatsapp": "5512976467884",
  "endereco": "Av. das Palmeiras, 245 — Centro, Santa Inês - MA, 65300-000",
  "instagram": "flipburguer",
  "cores": {
    "principal": "#E8590C",
    "secundaria": "#1C1917",
    "escuro": "#8A3B12"
  },
  "layout": "lista",
  "mostrarBanner": true,
  "fuso": "America/Sao_Paulo",
  "horarios": {
    "dom": [
      "18:00-23:00"
    ],
    "seg": [
      "18:00-23:00"
    ],
    "ter": [
      "18:00-23:00"
    ],
    "qua": [
      "18:00-23:00"
    ],
    "qui": [
      "18:00-23:00"
    ],
    "sex": [
      "18:00-23:00"
    ],
    "sab": [
      "18:00-23:00"
    ]
  },
  "fechadoManual": false,
  "tempoEntrega": "30 a 45 min",
  "tempoRetirada": "20 a 30 min",
  "aceitaEntrega": true,
  "aceitaRetirada": true,
  "taxaEntrega": 0,
  "pedidoMinimo": 0,
  "pagamentos": [
    "Pix",
    "Dinheiro",
    "Crédito",
    "Débito"
  ],
  "cupons": {
    "10OFF": {
      "tipo": "percentual",
      "valor": 10
    }
  },
  "banner": {
    "titulo": "Combo da casa",
    "subtitulo": "Toda terça",
    "imagem": "assets/banner.webp"
  },
  "seo": {
    "titulo": "Flip Burger Sabor que Vicia",
    "descricao": "Burgers artesanais, combos irresistíveis e muito sabor. Peça pelo WhatsApp e aproveite nossas promoções exclusivas.",
    "imagem": "assets/compartilhar.jpg",
    "url": ""
  },
  "urlPadrao": "https://{slug}.netlify.app",
  "categorias": [
    "Combos",
    "Burgers",
    "Bebidas"
  ],
  "grupos": {
    "ponto": {
      "titulo": "Ponto da carne",
      "tipo": "unico",
      "estilo": "escolha",
      "obrigatorio": true,
      "padrao": "Ao ponto",
      "opcoes": [
        {
          "nome": "Mal passado"
        },
        {
          "nome": "Ao ponto"
        },
        {
          "nome": "Bem passado"
        }
      ]
    },
    "adicionais": {
      "titulo": "Adicionais",
      "tipo": "multiplo",
      "estilo": "adicional",
      "prefixo": "+ ",
      "opcoes": [
        {
          "nome": "Bacon",
          "preco": 4
        },
        {
          "nome": "Queijo extra",
          "preco": 4
        }
      ]
    },
    "remover": {
      "titulo": "Remover",
      "tipo": "multiplo",
      "estilo": "remocao",
      "opcoes": [
        {
          "nome": "Sem cebola"
        },
        {
          "nome": "Sem tomate"
        },
        {
          "nome": "Sem molho"
        }
      ]
    }
  },
  "produtos": [
    {
      "id": "c1d49ef",
      "tipo": "combo",
      "categoria": "Combos",
      "nome": "Combo Flip Bacon",
      "preco": 56,
      "itens": [
        {
          "id": "pikzir6"
        },
        {
          "id": "pulyey7"
        }
      ],
      "descricao": "Hambúrguer artesanal com pão brioche, carne bovina suculenta, cheddar derretido, bacon crocante, cebola caramelizada, alface, tomate e molho especial da casa. Acompanha Guaraná gelado.",
      "imagem": "assets/produtos/combo-flip-bacon.webp"
    },
    {
      "id": "pikzir6",
      "categoria": "Burgers",
      "nome": "Flip Clássico",
      "preco": 56,
      "grupos": [
        "ponto",
        "adicionais",
        "remover"
      ],
      "descricao": "Pão brioche, hambúrguer bovino grelhado, queijo cheddar derretido, alface, tomate, cebola roxa e molho especial da casa.",
      "imagem": "assets/produtos/flip-classico.webp"
    },
    {
      "id": "pdgtjxt",
      "categoria": "Burgers",
      "nome": "Flip Bacon",
      "preco": 67,
      "grupos": [
        "ponto",
        "adicionais",
        "remover"
      ],
      "descricao": "Pão brioche, carne bovina suculenta, cheddar cremoso, bacon crocante, cebola caramelizada, alface, tomate e molho especial.",
      "imagem": "assets/produtos/flip-bacon.webp"
    },
    {
      "id": "p82ezw5",
      "categoria": "Burgers",
      "nome": "Flip Duplo",
      "preco": 57,
      "grupos": [
        "ponto",
        "adicionais",
        "remover"
      ],
      "descricao": "Pão com gergelim, dois hambúrgueres bovinos, cheddar duplo, picles, cebola, alface e molho especial da casa.",
      "imagem": "assets/produtos/flip-duplo.webp"
    },
    {
      "id": "p5yvx3z",
      "categoria": "Burgers",
      "nome": "Flip Chicken",
      "preco": 47,
      "grupos": [
        "ponto",
        "adicionais",
        "remover"
      ],
      "descricao": "Pão macio, filé de frango empanado e crocante, queijo cheddar, alface, tomate e molho cremoso especial.",
      "imagem": "assets/produtos/flip-chicken.webp"
    },
    {
      "id": "pulyey7",
      "categoria": "Bebidas",
      "nome": "Refrigerante Cola Gelado",
      "preco": 8,
      "descricao": "Refrigerante sabor cola servido bem gelado, ideal para acompanhar qualquer hambúrguer.",
      "imagem": "assets/produtos/refrigerante-cola-gelado.webp"
    },
    {
      "id": "pof0wub",
      "categoria": "Bebidas",
      "nome": "Guaraná Gelado",
      "preco": 8,
      "descricao": "Refrigerante sabor guaraná, leve, refrescante e servido bem gelado.",
      "imagem": "assets/produtos/guarana-gelado.webp"
    },
    {
      "id": "pruxvty",
      "categoria": "Bebidas",
      "nome": "Suco de Laranja Gelado",
      "preco": 9,
      "descricao": "Suco de laranja refrescante servido com gelo, perfeito para quem prefere uma opção frutada.",
      "imagem": "assets/produtos/suco-de-laranja-gelado.webp"
    },
    {
      "id": "ptgy9kd",
      "categoria": "Bebidas",
      "nome": "Milk-shake de Chocolate",
      "preco": 10,
      "descricao": "Milk-shake cremoso de chocolate, finalizado com chantilly, calda de chocolate e pedaços de chocolate.",
      "imagem": "assets/produtos/milk-shake-de-chocolate.webp"
    }
  ]
};
